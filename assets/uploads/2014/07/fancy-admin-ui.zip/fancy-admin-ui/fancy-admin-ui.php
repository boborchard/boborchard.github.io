<?php
  /*
  Plugin Name:  Fancy Admin UI
  Plugin URI:   http://boborchard.com/plugins/fancy-admin-ui/
  Description:  Super clean, blue admin panel theme
  Version:      0.1 Beta
  Author:       Bob Orchard
  Author URI:   http://boborchard.com
  */

/* Include Admin Styles */
function fau_admin_theme_style() {
    wp_enqueue_style('fau-admin-theme', plugins_url('css/fau-styles-admin.css', __FILE__));
}
add_action('admin_enqueue_scripts', 'fau_admin_theme_style');
add_action('login_enqueue_scripts', 'fau_admin_theme_style');

/* Login Page Styling */
function fau_login_theme_style() {
    wp_enqueue_style( 'fau-login-theme', plugins_url('css/fau-styles-login.css', __FILE__));
    wp_enqueue_script( 'fau-login-theme', plugins_url('css/fau-styles-login.css', __FILE__));
}
add_action( 'login_enqueue_scripts', 'fau_login_theme_style' );

function fau_change_admin_bar_menu_label() {
  global $wp_admin_bar;
  $wp_admin_bar->remove_menu('wp-logo');
  $wp_admin_bar->remove_menu('about');
  $wp_admin_bar->remove_menu('comments');
  $wp_admin_bar->remove_menu('wporg');
  $wp_admin_bar->remove_menu('documentation');
  $wp_admin_bar->remove_menu('support-forums');
  $wp_admin_bar->remove_menu('feedback');
  $wp_admin_bar->remove_menu('new-content');
  $wp_admin_bar->remove_menu('view');
  $wp_admin_bar->remove_menu('site-name');
  $wp_admin_bar->add_menu( array(
    'id'    => 'view-my-website',
    'title' => '<span class="icon dashicons-before dashicons-schedule"></span>View My Website',
    'href'  => get_site_url(),
    'target'=> '_blank'
  ));
}
//add_action( 'admin_bar_menu', 'fau_change_admin_bar_menu_label', 999 );

/* Making Things Disappear */

// Update Admin Footer
function fau_update_footer_admin () {
  echo 'Custom Admin UI by <a href="http://boborchard.com" target="_blank">Bob Orchard</a> | Powered by <a href="http://wordpress.org" target="_blank">Wordpress</a></p>';
}
add_filter('admin_footer_text', 'fau_update_footer_admin');