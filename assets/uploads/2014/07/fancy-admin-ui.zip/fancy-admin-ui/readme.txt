=== Plugin Name ===
Contributors: boborchard
Donate link: http://boborchard.com/wordpress-plugin-donations/
Tags: seo, tinymce
Requires at least: 3.9.0
Tested up to: 3.9
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Clean, blue UI for the Admin interface.

== Description ==

Clean, blue UI for the Admin interface.

== Installation ==

1. Upload `fancy-admin-ui.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==


== Changelog ==

= 0.1 Beta =
* Initial version for Wordpress 3.9.x